Thoughtspot Interview Experience ✌️
Compensation Range: 50-70LPA

Position: SSE

𝟏𝐬𝐭 𝐑𝐨𝐮𝐧𝐝 ☑️
```
- Basic Js theoretical questions
- groupBy polyfill
- Web performance
```


2𝐬𝐭 𝐑𝐨𝐮𝐧𝐝
```
- Build a typehead 
- how will you implement caching
- Follow up -: Implement list virtualization
- how will you handle race condition
```

3rd 𝐑𝐨𝐮𝐧𝐝 ⛔️
```
- Resolve async sequential promise using recursion
- Implement cancellable promise
```
