

# Uber interview experience

Uber Interview Experience ✌️

Position: SSE

Compensation - 50 base + around 40 esops

Credit - Bhasker joshi 

[Bhasker Linkedin profile](https://www.linkedin.com/in/bhaskarj61) 



**Round 1 DSA questions**
```
1. https://leetcode.com/problems/next-greater-element-i/description/ 
2. https://leetcode.com/problems/word-break/description/ 

Questions related to 
Virtual Dom
React fragments
Grids CSS 
polyfill of Array.reduce
```

**2nd 𝐃𝐒𝐀 𝐑𝐨𝐮𝐧𝐝 ☑️ - **
```
https://leetcode.com/problems/permutation-sequence/description/
```

**System design**
```
System design (60 min) 
Design a Chat UI
```


**Rejected** 

```
You should ask questions like types of messages supported like text, multimedia etc. 
Also you should focus on the variable naming of dummy data. It should be precise and descriptive. 
Dont waste on your time advance concepts without building the basic functionality first.
```
