# Uber interview experience

Uber Interview Experience ✌️

How I applied: through Instahyre
Position: SDE-2 (Frontend Engineer)

```
𝐒𝐜𝐫𝐞𝐞𝐧𝐢𝐧𝐠 𝐑𝐨𝐮𝐧𝐝 ☑️ (around 90 min)
1 DSA questions
📌 Find all anagrams in a string - https://leetcode.com/problems/find-all-anagrams-in-a-string/description/
📌 Asked HLD for my previous project completely on draw.io
```

```
𝐃𝐒𝐀 𝐑𝐨𝐮𝐧𝐝 ☑️ - 
 📌 Progress bar with dependency(topological sort) 
```

```
𝐌𝐚𝐜𝐡𝐢𝐧𝐞 𝐜𝐨𝐝𝐢𝐧𝐠 (60 min) 
📌 build a WhatsApp chat application 
📌 Follow up - message received in 5 sec (check-in js machine coding )
```
