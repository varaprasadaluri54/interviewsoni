Apollo.io Interview Experience ✌️
The compensation range - 50-70 LPA

How I applied: Through referral
Position: SSE

𝟏𝐬𝐭 𝐑𝐨𝐮𝐧𝐝 ☑️
📌 2 DSA questions:
- A HashMap-based easy question - Two sum
- Finding the sum of consecutive digits of an array until it becomes a single digit.
- React-based machine coding question- easy question display images and display in modal(already part of written code)


𝐌𝐚𝐜𝐡𝐢𝐧𝐞 𝐂𝐨𝐝𝐢𝐧𝐠 𝐑𝐨𝐮𝐧𝐝 ⛔️
📌 Task: Build a To-Do List application.

Js functionality
- Create item
- Toggle item
- Delete item
- filter item
- item count

CSS functionality
- The main input field and item rows should be centered and take 85% of the screen’s width with a max width of 500px.
- The item's middle section with the text should take up the entire row width minus the circle and “x”.
- The item rows should have non-overlapping borders.
- The “x” should only show if the row is being hovered.

![Image](https://github.com/user-attachments/assets/49d1fdce-1140-450f-b812-e1424275d5e7)

