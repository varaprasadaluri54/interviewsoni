Atlassian

Applied via: Recruiter reached out through LinkedIn

Compensation: ₹47,00,000 + ₹20,00,000 (stock) ≈ ₹80 LPA



## Round 1:
```
- Reverse the order of the words by removing spaces. (https://leetcode.com/problems/reverse-words-in-a-string/description/)
- Build a lazy-loading tab reusable component
```

## Round 2:
```
- Build a function to measure the performance of a given function (sync/async) 
- A few questions on Redux and data normalization.
```


## Round 3: System Design
```
- Design Google Docs-style editor and Follow-up questions:
- Conflict resolution algorithms - CRDT vs OT
- How would you handle offline editing and syncing?
- system architecture
- How would you persist and version document history.
- How would you support offline editing and ensure data sync upon reconnection.
```

Rejected 💔
