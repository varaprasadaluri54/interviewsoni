# Salesforce Interview experience

How I applied: HR reached out to me via LinkedIn

Position: SDE-2 (Frontend Engineer)

```
**Assessment Round** ☑️
2 DSA questions (Medium-hard difficulty)
📌 Easy array and hashmap-based
📌 Hard undirected graph question - Don't remember exact problem but
similar to https://leetcode.com/problems/evaluate-division/description/

Well I have used Chat GPT :)
```

```
𝐃𝐒𝐀 𝐑𝐨𝐮𝐧𝐝 ☑️
 📌 Odd String Difference - https://lnkd.in/gD6Yyg7f
I got stuck initially but was finally able to solve it.
📌 Similar question to: Product of Array Except for Self
```

```
𝐉𝐚𝐯𝐚𝐒𝐜𝐫𝐢𝐩𝐭 𝐑𝐨𝐮𝐧𝐝 ☑️
📌 Easy hashmap-based group-by-polyfill
📌 Implement Promise.all
📌 Implement LRU caching
```

```
𝐌𝐚𝐧𝐚𝐠𝐞𝐫𝐢𝐚𝐥 𝐑𝐨𝐮𝐧𝐝 ☑️
📌 About my previous projects
📌 Few scenario-based questions
📌 Implement flood fill algorithm
```
