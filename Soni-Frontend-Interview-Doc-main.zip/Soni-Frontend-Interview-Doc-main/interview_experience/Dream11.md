Dream11 Interview Experience ✌️ (2022)
Compensation Range: 40-50 LPA + ESOPs
Position: SE
applied through: Linkedin

𝟏𝐬𝐭 𝐑𝐨𝐮𝐧𝐝 (𝐃𝐒𝐀)
```
- 3-Sum
- Question related to the Sliding Window technique.
```

𝟐𝐧𝐝 𝐑𝐨𝐮𝐧𝐝
```
- 3 coding snippets 
- Implementation of Promise.any
- Memoization function
- Clear all timeouts
- Difference between: display: none, visibility: hidden, opacity: 0
```



𝟑𝐫𝐝 𝐑𝐨𝐮𝐧𝐝 (𝐒𝐲𝐬𝐭𝐞𝐦 𝐃𝐞𝐬𝐢𝐠𝐧)
```
📌 Given a list of 3 APIs, I had to design an app that:
👉 Displays a list of books
👉 Selects a book on click
👉 Implements infinite scrolling (loads next page seamlessly)

Follow-up Questions:
- What if there are 100K pages?
- How would you handle if the user jumps to a random page?
- How can you ensure efficient rendering when dealing with a large dataset?
- How would you cache data to optimize performance for mobile users?
- What strategies can be used to reduce unnecessary API calls?
```

𝐌𝐚𝐧𝐚𝐠𝐞𝐫𝐢𝐚𝐥 𝐑𝐨𝐮𝐧𝐝
```
Discussion on past projects and experience
```


