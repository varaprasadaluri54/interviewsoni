Apollo.io Interview Experience ✌️
The compensation range - 50-70 LPA

How I applied: Through referral
Position: SSE

𝐏𝐡𝐨𝐧𝐞 𝐬𝐜𝐫𝐞𝐞𝐧𝐢𝐧𝐠 𝐫𝐨𝐮𝐧𝐝
```
React assessment - a basic flip card application. 
The basic layout was already there. I have to work on top of it and pass a few test cases.
```

𝟏𝐬𝐭 𝐑𝐨𝐮𝐧𝐝
```
- Easy hashmap-based question - filter object data
- Polyfill for Promise.allSettled()
- Discussion on hooks and their use cases
- useLayoutEffect hook
- Polyfill for useEffect in React
```

𝟐𝐧𝐝 𝐑𝐨𝐮𝐧𝐝
```
- Asked about project architecture
- How to build a project from scratch, followed by a few follow-up questions
-  Implemented an interactive diagonal feature
```


𝟑𝐫𝐝 𝐑𝐨𝐮𝐧𝐝 (𝐌𝐚𝐧𝐚𝐠𝐞𝐫𝐢𝐚𝐥)
```
- Basic leadership and behavioral questions
- Detailed discussion on unit test cases with edge cases (They provided an environment to write unit tests)
- Discussion on previous projects.
```
