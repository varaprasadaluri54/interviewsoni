# Mindtickle Interview Experience ✌️

The compensation Range is quite good around  40-60 LPA

How I applied: Direct apply
Position: SDE-2 (Frontend Engineer)

```
𝐒𝐜𝐫𝐞𝐞𝐧𝐢𝐧𝐠 𝐑𝐨𝐮𝐧𝐝 ☑️ 
2 DSA questions Conducted by InterviewVector
📌 Square of sorted array
 [Link](https://leetcode.com/problems/squares-of-a-sorted-array/description/)
📌 Hashmap based question medium question(similar) 
[Link](https://leetcode.com/problems/longest-consecutive-sequence/description/)
```

```
𝐉𝐚𝐯𝐚𝐬𝐜𝐫𝐢𝐩𝐭 𝐑𝐨𝐮𝐧𝐝 ⛔️
 📌 3 output based question (check code snippet sections)
 📌 Filter-based easy question
 📌 build a tab component in react (check machine coding question)
```

Rejected 🚀
