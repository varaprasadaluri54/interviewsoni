Rippling Interview Experience ✌️
Compensation Range: 60-80 LPA

Position: SSE
Application Method: Direct

```
𝟏𝐬𝐭 𝐑𝐨𝐮𝐧𝐝 ☑️
📌 Basic Introduction
📌 Discussion about previous projects
📌 Web performance - specifically about caching
```

```
𝐑𝐞𝐬𝐜𝐡𝐞𝐝𝐮𝐥𝐞𝐝 𝐑𝐨𝐮𝐧𝐝 ⛔️
📌 Advanced memoization (added in Soni's Frontend Document)
📌 mapLimit with a follow-up question on a stream of data
```
[mapLimit](https://github.com/Soni-Fronteend-Organisation/Soni-Frontend-Interview-Doc/blob/main/JS_Coding_Questions/mapLimit.js)
Follow up 
- what if data is streamed in over every 1sec with timer lets say [{taskName: "task1", resolvediTime: 1000 }, {taskName: "task2", resolvediTime: 3000 }, {taskName: "task2", resolvediTime: 2000 }]
- how will you prioritize tasks that can be resolved in a parallel way?

- [Memoization](https://github.com/Soni-Fronteend-Organisation/Soni-Frontend-Interview-Doc/blob/main/JS_Coding_Questions/memoization.js)
