Google Interview Experience ✌️

Compensation Range: 90LPA - 1cr(Including stocks)

Applied via - Referral


𝟏𝐬𝐭 𝐑𝐨𝐮𝐧𝐝 (𝐃𝐒𝐀)
```
I was given an extended version of the merging intervals question with streaming data 


Question - Build a class that takes a stream of number ranges and automatically merges any overlapping ones.
Also, add a method to quickly check if a given number falls within any of the stored ranges.
```

𝟐𝐧𝐝 𝐑𝐨𝐮𝐧𝐝
```
I was asked to implement a Promise from scratch and, as a follow-up, to implement the final method.
```


𝟑𝐫𝐝 𝐑𝐨𝐮𝐧𝐝 
```
The question was graph-related, an extended version of finding the shortest distance in an undirected graph

Questions:
Find the shortest distance between two nodes in an undirected graph.
Follow-up: If any intermediate node between the source and destination is blocked, what is the maximum possible distance between them?
```


**Overall Experience**
Rejected
