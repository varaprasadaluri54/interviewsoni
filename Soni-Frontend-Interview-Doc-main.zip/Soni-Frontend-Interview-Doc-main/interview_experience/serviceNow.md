ServiceNow Interview Experience ✌️


**Compensation Range**: Around 40 LPA + 10-12LPA RSUs

**Position**: SSE

**Applied Through**: Linkedin



**1st Round ☑️**
```
1. var a = [1,2,3,4,5][0,1,2,3,4]; console.log(a);
  tried different approaches, but I couldn't give right answer.
2. Difference between Promise.resolve and Promise.reject, along with their polyfills.
3. const list = [1,2,3,4,5,6,7]; — Get the max element from this list using ES5.
4. Sort an array
5. Bit manipulation DSA question 
  Given an array var a = [1, 2, 3, 4, 5];
  Write a function to count the number of valid pairs in the array where XOR > AND.
```

**2nd Round**
```
1. Validate an HTML string.
2. Implement JSON.parse().

```

Before the 3rd Round
They asked about my salary expectations but weren’t offering more than Amazon, so I decided not to move forward.

