// Implement typehead
// Implement caching for result

