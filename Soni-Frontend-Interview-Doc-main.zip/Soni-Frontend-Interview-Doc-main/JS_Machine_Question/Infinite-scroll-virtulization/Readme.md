Build a virtual scroll implementation where only visible items are rendered as the user scrolls down.
Dynamically loading new content as the user approaches the bottom.

usually interviewer tell us to use MDN doc for such type of questions,
if not its your bad day(until you are good at mugging up things)