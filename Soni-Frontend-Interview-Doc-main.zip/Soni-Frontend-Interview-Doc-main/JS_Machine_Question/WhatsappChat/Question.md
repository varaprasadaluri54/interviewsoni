Question:

// Implement a chat UI where the user can send a message, and it appears on the right side.
// Define the API response structure to simulate receiving a message with message, createdAt.
// Set up an automatic system to fetch and display a new message on the left every 10 seconds.
