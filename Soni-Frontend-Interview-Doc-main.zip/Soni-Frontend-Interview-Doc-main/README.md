**JS Machine coding questions included in Doc:**
![Doc](https://github.com/user-attachments/assets/654b8d96-4347-440a-9bd4-44061e25d151)
