Company - JP Morgan

LinkedIn profile - https://www.linkedin.com/in/dimple-kumari/

Compensation - ~30LPA

𝗥𝗼𝘂𝗻𝗱 𝟭: 𝗝𝗮𝘃𝗮𝗦𝗰𝗿𝗶𝗽𝘁 + 𝗣𝗿𝗼𝗷𝗲𝗰𝘁 𝗦𝘆𝘀𝘁𝗲𝗺 𝗗𝗶𝘀𝗰𝘂𝘀𝘀𝗶𝗼𝗻 (𝟲𝟬 𝗺𝗶𝗻𝘀)
```
- Started with an in-depth discussion on my project responsibilities and 
  architect was asked to illustrate the overall project flow using a diagram
- How do we handle sensitive data securely on the frontend
- Scenario-based async problem: multiple async operations with partial failure handling
- Asked to write a polyfill for bind and explain the use of call, apply, and bind
- Object manipulation task based on nested JSON structures
- Covered frontend performance optimizations:
    - Debouncing and throttling
    - Code splitting and dynamic imports
    - Critical CSS extraction
    - Reducing reflows and repaints
    - Optimizing third-party script loading
```

✅ 𝗥𝗼𝘂𝗻𝗱 𝟮: 𝗥𝗲𝗮𝗰𝘁 + 𝗪𝗲𝗯 𝗦𝗲𝗰𝘂𝗿𝗶𝘁𝘆 (𝟲𝟬 𝗺𝗶𝗻𝘀)
```
- Detailed discussion on React lifecycle methods in both class and functional components
- Explored useEffect behavior during re-renders and dependency updates
- Questions around component structuring, state management, and props handling
- Security-focused scenario: how to safely render user-generated content and avoid XSS
- Web security:
    - How to safely render dynamic HTML and prevent XSS
    - Protecting against Cross-Site Request Forgery (CSRF) using tokens
    - Implementing input sanitization and output encoding
    - Defending against content spoofing, clickjacking, and open redirects
- Asked how I approach secure storage handling (localStorage / sessionStorage)
```

❌ 𝗥𝗼𝘂𝗻𝗱 𝟯: Not able to give 
```
Everything was on track until the final round turned out to be a face-to-face interview in Bangalore. I was in my hometown due to an emergency and couldn’t make it.
Sometimes, it's not the skills — it’s just the timing.
```
