PayPal Interview Experience

Compensation Range: ~23lpa + stocks

Position - SDE-2 (Frontend Engineer)

Applied through: direct call from recruiter

1st Round – Domain-Specific Round
```
- Discussion on previous projects
- Difference between DOM and BOM
- ES6 features and again, 
- What is web accessibility? (with some follow-up questions)
- Implemented a typeahead:
    - Should populate the list using the search keyword 
    - A delete icon should clear the input field


Result – Went average ❤️
```





2nd Round – DSA
```
- Anagram problem
- Array.sort() polyfill – Got stuck while explaining the recursion part of Quick Sort

- Rejected - flying rejected mail
```


