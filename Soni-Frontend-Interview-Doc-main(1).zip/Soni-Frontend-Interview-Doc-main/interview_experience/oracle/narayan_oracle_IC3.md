Narayan Oracle experience
Position - Oracle IC3


**Round 1**
```
Question 1: 8-9 Promise changing problem code snippet 
Question 2: transfer list, react machine coding question.
```

**Round 2  (1.5hr)**
```
1. How did you implement virtualization
2. One MCQ based on asynchronous code
3. Write Singleton Pattern
4. Write pubsub pattern for time machine
5. polyfills of Promise(all)
6. What is HOC?
7. Custom hook
8. What is memoisation, debouncing
9. event bubbling, propagation & their use case
10. react life cycle, Virtual Dom, useEffect vs useLayoutEffect, useRef
11. theoretical questions on context-api, pure component, event loop, forward ref
```

**Round 3:**
```
login form design for UI
```

**4th HM round:**
```
1. reason for the switch
2. Asked major contribution, the reason you stayed in the current company for four years.
3. 2nd maximum array in the element
4. Event loop in JS
```

Got an offer for IC2
