# Tekion Interview Experience

```
Compensation Range: 40+ LPA 
ESOPs 
Position: SDE-2 
Applied through: LinkedIn
```

**Rounds 1(JS + Algo)**
```
1. Currying-based output questions and implementations - curry(1)(2)(3)()
2. DSA - unique employee(s) who do not appear in any other organization.
[
  { name: "A", org: "Google" },
  { name: "B", org: "Amazon" },
  { name: "A", org: "Google" },
  { name: "A", org: "Meta" },
  { name: "C", org: "Amazon" },
  { name: "D", org: "Google" }
]

{
  Google: ["D"],
  Amazon: ["C"],
  Meta: []
}


3. Working of Promises (event loop + microtask queue)
4. React class component lifecycle like mounting → updating → unmounting)
```

**(Advanced JS + Rendering Concepts)**
```
1. Debounce vs Throttle difference and Throttle polyfill explanations
2. CSS animations: why transform is preferred over other properties
3. Event propagation: Bubbling vs Capturing, use cases, why it happens
4. Reflow vs Repaint in browser rendering
5. Write a Promise polyfill with multiple use cases
```

**Technical Onsite Round 4**
```
1. Use createInstance to instantiate components without the new keyword
2. Write an async scheduler that runs async tasks in parallel with max concurrency limit
3. List endering optimisation: virtualized lists
4. Create React-like class components using ES5
```
